Dhaiveeshya A portfolio

index.html  - page
style.css   - styles
script.js   - animations, ribbon cursor, slider
assets/resume.jpg, assets/resume.pdf - resume files

Open index.html in a browser, or upload this folder to GitHub Pages or Netlify.
The live emotion demo only works inside the Claude page and stays hidden elsewhere.
